package login;

import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class frmLoginMaestro extends JFrame {
	
	private static final long serialVersionUID = 1L;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frmLoginMaestro frame = new frmLoginMaestro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	public frmLoginMaestro() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 450, 400);
		setLayout(null);
		setLocationRelativeTo(null);
		setUndecorated(true);/*sin bordes*/ 
		
		JPanel pnlLogin = new JPanel() ;
		pnlLogin.setBounds(0, 0, 450, 50);
		pnlLogin.setLayout(null);
		pnlLogin.setBackground( new Color(94,17,97) );
		getContentPane().add(pnlLogin);
		
		JLabel imgLogo = new JLabel();
		imgLogo.setIcon(new ImageIcon(frmLoginMaestro.class.getResource("/login/logo.png")));
		imgLogo.setBounds(71, 3, 208 , 43);
		pnlLogin.add(imgLogo);
		
		JLabel imgCerrar = new JLabel();
		imgCerrar.setIcon(new ImageIcon(frmLoginMaestro.class.getResource("/login/salir.png")));
		imgCerrar.setBounds(400, 16, 32 , 32);
		pnlLogin.add(imgCerrar);
		
	
		
		
	}

}
