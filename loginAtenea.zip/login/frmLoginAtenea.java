package login;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.EventQueue;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class frmLoginAtenea extends JFrame {
	
	private static final long serialVersionUID = 1L;
	JTextField txtUsuario;
	JPasswordField txtPassword;
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frmLoginAtenea frame = new frmLoginAtenea();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


	public frmLoginAtenea() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 400, 300);
		getContentPane().setLayout(null);
		setLocationRelativeTo(null);
		setUndecorated(true);/*sin bordes*/ 
		
		JPanel pnlLogin = new JPanel() ;
		pnlLogin.setBounds(0, 0, 400, 50);
		pnlLogin.setLayout(null);
		pnlLogin.setBackground( new Color(94,17,97) );
		getContentPane().add(pnlLogin);
		
		JLabel imgLogo = new JLabel();
		imgLogo.setIcon(new ImageIcon(frmLoginAtenea.class.getResource("/login/logo.png")));
		imgLogo.setBounds(96, 3, 208 , 43);
		pnlLogin.add(imgLogo);
		
		JLabel imgSalir = new JLabel();
		imgSalir.setIcon(new ImageIcon(frmLoginAtenea.class.getResource("/login/salir.png")));
		imgSalir.setBounds(365, 14, 32 , 32);
		pnlLogin.add(imgSalir);
		
		JLabel lblUsuario = new JLabel ("Usuario : ");
		lblUsuario.setBounds(50, 100, 80, 30);
		getContentPane().add(lblUsuario);
	
		JLabel lblPassword = new JLabel ("Password : ");
		lblPassword.setBounds(50, 150, 80, 30);
		getContentPane().add(lblPassword);
		
		txtUsuario = new JTextField();
		
		txtUsuario.setBounds(200, 100, 100, 30);
		getContentPane().add(txtUsuario);
		
		txtPassword = new JPasswordField();
		
		txtPassword.setBounds(200, 150, 100, 30);
		txtPassword.setEchoChar('*');
		getContentPane().add(txtPassword);
		
		JButton btnIniciar = new  JButton("Iniciar");
		btnIniciar.setBounds(75, 230, 100, 30);
		btnIniciar.setBackground(new Color(94, 17, 97));
		btnIniciar.setBorderPainted(false);	
		btnIniciar.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnIniciar.setForeground(Color.white);
		btnIniciar.setFocusPainted(false);
		getContentPane().add(btnIniciar);
		
		JButton btnCancelar = new  JButton("Cancelar");
		btnCancelar.setBounds(230, 230, 100, 30);
		btnCancelar.setBackground(new Color(94, 17, 97));
		btnCancelar.setBorderPainted(false);	
		btnCancelar.setCursor(new Cursor(Cursor.HAND_CURSOR));
		btnCancelar.setForeground(Color.white);
		btnCancelar.setFocusPainted(false);
		getContentPane().add(btnCancelar);
		
		txtUsuario.addFocusListener(new FocusAdapter() {
			@Override public void focusGained(FocusEvent e) {txt_focusGainet(e);}
			@Override public void focusLost(FocusEvent e) {txt_focusLost(e); } });
		
		txtPassword.addFocusListener(new FocusAdapter() {
			@Override public void focusGained(FocusEvent e) {txt_focusGainet(e);}
			@Override public void focusLost(FocusEvent e) {txt_focusLost(e); } });
	
		btnIniciar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { btnIniciar_actionPerformed();} });
		btnIniciar.addFocusListener(new FocusAdapter() {
			@Override public void focusGained(FocusEvent e) {btn_focusGained(btnIniciar); }
			@Override public void focusLost(FocusEvent e) {btn_focusLost(btnIniciar);} });
		
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) { btnCancelar_actionPerformed();} });
		btnCancelar.addFocusListener(new FocusAdapter() {
			@Override public void focusGained(FocusEvent e) {btn_focusGained(btnCancelar); }
			@Override public void focusLost(FocusEvent e) {btn_focusLost(btnCancelar);} });
		
	}


	

	protected void btn_focusLost(JButton btnIniciar) {
		// TODO Auto-generated method stub
		
	}


	protected void btn_focusGained(JButton btnIniciar) {
		// TODO Auto-generated method stub
		
	}


	protected void btnIniciar_actionPerformed() {
		// TODO Auto-generated method stub
		
	}
	
	protected void btnCancelar_actionPerformed() {
		// TODO Auto-generated method stub
		
	}


	protected void txt_focusLost(FocusEvent e) {
		((JTextField)e.getSource()).setBackground(new Color(215, 230, 255));
		
	}


	protected void txt_focusGainet(FocusEvent e) {
		((JTextField)e.getSource()).setBackground(Color.white);
		
	}

}
