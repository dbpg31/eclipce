package repetitivas;

import java.awt.EventQueue;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class _05 extends JFrame {
	private static final long serialVersionUID = 1L;
	
	JTextField txtNumero, txtTabla;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					_05 frame = new _05();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public _05() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 250, 350);
		setLocationRelativeTo( null );
		setLayout(null);
		
		JLabel lblNumero = new JLabel("Número :");
		lblNumero.setBounds(30, 30, 60, 25);
		getContentPane().add(lblNumero);
		
		JLabel lblTabla = new JLabel("Tabla :");
		lblTabla.setBounds(30, 60, 70, 25);
		getContentPane().add(lblTabla);
		
		txtNumero = new JTextField();
		txtNumero.setBounds(100, 30, 50, 25);
		txtNumero.setMargin( new Insets( 2, 5, 2, 5 ));
		txtNumero.setHorizontalAlignment(SwingConstants.RIGHT);
		getContentPane().add(txtNumero);
		
		txtTabla = new JTextField();
		txtTabla.setBounds(100, 60, 80, 150);
		txtTabla.setFocusable(false);
		txtTabla.setMargin( new Insets( 2, 5, 2, 5 ));
		getContentPane().add(txtTabla);
		
		JButton btnCalcular = new JButton("Calcular");
		btnCalcular.setBounds(60, 250, 100, 30);
		btnCalcular.setMnemonic('a');
		getContentPane().add(btnCalcular);

		btnCalcular.addActionListener( new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnCalcular_actionPerformed(); } });
	}

	private void btnCalcular_actionPerformed() {
		int numero = Integer.parseInt( txtNumero.getText() );
		
		for (int i = 0 ; i <= 12;)
		
		
		txtTabla.setText(i + "X" + numero + "=" + (i * numero) );
	}

}


