package repetitivas;

import java.awt.EventQueue;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class _14 extends JFrame {
	private static final long serialVersionUID = 1L;
	
	JTextField txtNumero, txtPrimo;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					_14 frame = new _14();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public _14() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, 300, 250);
		setLocationRelativeTo( null );
		setLayout(null);
		
		JLabel lblNumero = new JLabel("Número Primo :");
		lblNumero.setBounds(30, 30, 120, 25);
		getContentPane().add(lblNumero);
		
		JLabel lblPrimo = new JLabel("Es :");
		lblPrimo.setBounds(30, 60, 120, 25);
		getContentPane().add(lblPrimo);
		
		txtNumero = new JTextField();
		txtNumero.setBounds(130, 30, 50, 25);
		txtNumero.setMargin( new Insets( 2, 5, 2, 5 ));
		txtNumero.setHorizontalAlignment(SwingConstants.RIGHT);
		getContentPane().add(txtNumero);
		
		txtPrimo = new JTextField();
		txtPrimo.setBounds(130, 60, 100, 25);
		txtPrimo.setFocusable(false);
		txtPrimo.setMargin( new Insets( 2, 5, 2, 5 ));
		getContentPane().add(txtPrimo);
		
		JButton btnCalcular = new JButton("Calcular");
		btnCalcular.setBounds(60, 120, 100, 30);
		btnCalcular.setMnemonic('a');
		getContentPane().add(btnCalcular);

		btnCalcular.addActionListener( new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnCalcular_actionPerformed(); } });
	}

	private void btnCalcular_actionPerformed() {
		int numero = Integer.parseInt( txtNumero.getText() );
		//int tope = numero % 2 == 0 ? numero / 2 : numero / 3; 
		//int tope = numero / ( numero % 2 == 0 ? 2 : 3);
					
		//int tope = numero;
		String sDivisores = "1";
		
		//for ( int i=2; i <= tope; i++ )
			if ( numero % numero == 0 )
				sDivisores = "primo"; 
			
			
		else txtPrimo.setText("No es primo");
		
		
		txtPrimo.setText( sDivisores );
	}

}

